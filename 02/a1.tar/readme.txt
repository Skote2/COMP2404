Read Me
Author: David N Zilio 100997259 || Thuvarakan Thanabalasingam 101005310
Purpose: Set up a shop that allows customers to purchase items and tally up points
Source File: CustArray.cc, CustArray.h, Customer.cc, Customer.h, defs.h, InvControl.cc, InvControl.h, main.cc, Makefile, ProdArray.cc, ProdArray.h, Product.cc, Product.h, PurchArray.cc, PurchArray.h, Purchase.cc, Purchase.h, Store.cc, Store.h, UI.cc, UI.h
Compilation Command: make
Launching and operating instructions: ./cushop -c